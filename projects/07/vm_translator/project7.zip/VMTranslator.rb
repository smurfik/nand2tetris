require_relative "parser"
require_relative "code_writer"

module VmTranslator

  def self.create_asm_file
    file_name = ARGV[0]
    temp = file_name.split("/")
    vm_file = temp.pop
    path = temp.join("/") + "/"
    file = vm_file.split(".")[0]
    code_writer = CodeWriter.new(file, path)
    file_contents = ARGF.read
    parser = Parser.new(file_contents)
    while parser.has_more_commands?
      parser.advance
      case parser.command_type
      when Parser::C_ARITHMETIC
        code_writer.write_arithmetic(parser.arg1)
      when Parser::C_PUSH
        code_writer.write_push_pop(parser.command_type,
                                   parser.arg1,
                                   parser.arg2)
      end
    end
  end
end

VmTranslator.create_asm_file
